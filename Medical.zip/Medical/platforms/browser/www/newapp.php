
<html>


<style>
#p01 {
    color: blue;
}

select {

  display: block;
  padding: 10px 70px 10px 13px !important; 
  max-width: 100%; height: auto !important; 
  border: 1px solid #e3e3e3; border-radius: 3px; 
  background: url("https://image.ibb.co/iMeAJv/selectbox_arrow.png") right center no-repeat;
  background-color: #fff; color: #444444;
  font-size: 12px;
  line-height: 16px !important;
  appearance: none;
  /* this is must */ -webkit-appearance: none; 
  -moz-appearance: none; } 

Read more at: https://www.proy.info/style-select-dropdown-using-css/
}
</style>



<body>
<h1 id="p01">Appointment page</h1>

<form name="form1" action="" method="Post">
<label>Services:</label>
<select class="s1">
 <option value="as">Physician assistants</option>
   <option value="saab">Nurse practitioners</option>
  <option value="cl">Clinical nurse specialists</option>
  <option value="social">Clinical social workers</option>
  <option value="phy">Physical therapists</option>
  
</select></br>	


<input type="submit" value="submit">
</body>
</html>