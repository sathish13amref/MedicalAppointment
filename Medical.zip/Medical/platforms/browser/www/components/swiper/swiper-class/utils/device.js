import Device from '../../../../utils/device';

export default Device;
